#!/bin/bash

export ARIAL2=1.35.0
export SDL2=2.0.12
export SDL2_IMAGE=2.0.5
export SDL2_MIXER=2.0.4
export SDL2_TTF=2.0.15
export GSTREAMER=1.16.2
export PLATYPUS=5.3
